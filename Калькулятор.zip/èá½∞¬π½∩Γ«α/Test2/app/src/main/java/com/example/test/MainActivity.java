package com.example.test;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.*;

public class MainActivity extends AppCompatActivity  implements View.OnClickListener{
Button btn_plus;
Button btn_minus;
Button btn_division;
Button btn_multiplication;
TextView result;
EditText num1 ;
EditText num2;
double nums1;
double nums2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btn_division= findViewById(R.id.btn_division);
        btn_minus = findViewById(R.id.btn_minus);
        btn_plus= findViewById(R.id.btn_plus);
        btn_multiplication = findViewById(R.id.btn_multiplication);
        result = findViewById(R.id.Result);
    num1 = findViewById(R.id.EditText_1);
    num2 = findViewById(R.id.EditText_2);
    btn_plus.setOnClickListener(this);
    btn_multiplication.setOnClickListener(this);
    btn_division.setOnClickListener(this);
    btn_minus.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (num1.getText().toString().equals("") ||num2.getText().toString().equals("")){
            Toast.makeText(MainActivity.this, "Ввидите оба числа ", Toast.LENGTH_SHORT).show();}
        else {
 if (v.getId() == R.id.btn_minus){
     nums1 = Double.parseDouble(num1.getText().toString());
     nums2 = Double.parseDouble(num2.getText().toString());
     result.setText(String.valueOf(nums1-nums2));
    // Toast.makeText(MainActivity.this , "Нажата кнопка -",Toast.LENGTH_SHORT).show();
        }
else if (v.getId()==R.id.btn_plus){
nums1 = Double.parseDouble(num1.getText().toString());
nums2 = Double.parseDouble(num2.getText().toString());
result.setText(String.valueOf(nums1+nums2));
  //   Toast.makeText(MainActivity.this , "Нажата кнопка +",Toast.LENGTH_SHORT).show();
}
else if (v.getId() == R.id.btn_division){
//Toast.makeText(MainActivity.this , "Нажата кнопка /",Toast.LENGTH_SHORT).show();
     nums1 = Double.parseDouble(num1.getText().toString());
     nums2 = Double.parseDouble(num2.getText().toString());
     if (nums2 ==0)
         result.setText("Для вас есть отдельный котел в аду ");
     else
     result.setText(String.valueOf(nums1/nums2));
 }
 else if (v.getId()==R.id.btn_multiplication){
     nums1 = Double.parseDouble(num1.getText().toString());
     nums2 = Double.parseDouble(num2.getText().toString());
     result.setText(String.valueOf(nums1*nums2));
  //   Toast.makeText(MainActivity.this , "Нажата кнопка *",Toast.LENGTH_SHORT).show();
 }
    }
}}
